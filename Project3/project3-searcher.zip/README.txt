In basicSearch, I check the validation of numResultsToSkip and numResultsToReturn first to skip the wrong case;

In SearchResult, I didn’t know to use “+lx+” instead of “lx” in the query statement at first. But I debug it finally.

